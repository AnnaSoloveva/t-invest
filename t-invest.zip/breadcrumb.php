<div class="breadcrumb-block">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li><a href="#">Главная</a></li>
            <li><a href="#">Объекты</a></li>
            <li class="active">ул. 1 Линия</li>
        </ol>
    </div>
</div>