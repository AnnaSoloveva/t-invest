<?include("header.php")?>
<?include ("breadcrumb.php")?>

<div class="content">
    <div class="container-fluid">
        <h1 class="header404"><span>404</span><br>Страница не найдена</h1>
    </div>
    <div class="belt">
        <div class="container-fluid">
            <h2>Карта сайта</h2>
            <ul>
                <li><a href="/">Главная</a></li>
                <li>
                    <a href="/object.php">Объекты</a>
                    <ul>
                        <li><a href="#">Дом 2</a> </li>
                        <li><a href="#">Дом 3</a> </li>
                        <li><a href="#">Дом 4</a> </li>
                    </ul>
                </li>
                <li><a href="#">Контакты</a> </li>
            </ul>
        </div>
    </div>
</div>

<?include("footer.php")?>